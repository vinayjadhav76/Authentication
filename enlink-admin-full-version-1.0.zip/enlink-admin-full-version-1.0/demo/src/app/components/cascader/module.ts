import { NzCascaderModule } from 'ng-zorro-antd/cascader';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzButtonModule } from 'ng-zorro-antd/button';

export const moduleList = [ NzCascaderModule, NzModalModule, NzButtonModule ];
