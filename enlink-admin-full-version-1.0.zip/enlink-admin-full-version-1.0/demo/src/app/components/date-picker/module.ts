import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzButtonModule } from 'ng-zorro-antd/button';

export const moduleList = [ NzDatePickerModule, NzRadioModule, NzButtonModule ];
