import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';
import { NzButtonModule } from 'ng-zorro-antd/button';

export const moduleList = [ NzCheckboxModule, NzButtonModule ];
