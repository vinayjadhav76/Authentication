import { NzCollapseModule } from 'ng-zorro-antd/collapse';
import { NzIconModule } from 'ng-zorro-antd/icon';

export const moduleList = [ NzCollapseModule, NzIconModule ];
