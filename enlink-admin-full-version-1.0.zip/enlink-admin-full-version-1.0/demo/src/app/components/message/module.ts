import { NzMessageModule } from 'ng-zorro-antd/message';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzIconModule } from 'ng-zorro-antd/icon';

export const moduleList = [ NzMessageModule, NzButtonModule, NzIconModule ];
