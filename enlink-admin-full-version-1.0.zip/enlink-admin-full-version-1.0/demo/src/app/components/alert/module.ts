import { NzAlertModule } from 'ng-zorro-antd/alert';

export const moduleList = [ NzAlertModule ];
