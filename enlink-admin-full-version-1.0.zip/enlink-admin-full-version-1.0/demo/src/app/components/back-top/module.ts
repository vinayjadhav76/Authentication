import { NzBackTopModule } from 'ng-zorro-antd/back-top';

export const moduleList = [ NzBackTopModule ];
