import { NzInputModule } from 'ng-zorro-antd/input';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzCascaderModule } from 'ng-zorro-antd/cascader';
import { NzInputNumberModule } from 'ng-zorro-antd/input-number';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { FormsModule } from '@angular/forms';

export const moduleList = [
  FormsModule,
  NzInputModule,
  NzSelectModule,
  NzCascaderModule,
  NzInputNumberModule,
  NzDatePickerModule,
  NzIconModule,
  NzToolTipModule,
  NzButtonModule
 ];
