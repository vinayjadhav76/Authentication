import { Component } from '@angular/core';

@Component({
  selector: 'nz-demo-empty-basic',
  template: `
    <nz-empty></nz-empty>
  `
})
export class NzDemoEmptyBasicComponent {}
