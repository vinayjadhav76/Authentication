import { Component } from '@angular/core';

@Component({
  selector: 'nz-demo-empty-simple',
  template: `
    <nz-empty nzNotFoundImage="simple"></nz-empty>
  `
})
export class NzDemoEmptySimpleComponent {}
